+++
title = "Slide title"
type="slide"

theme = "league"
[revealOptions]
transition= 'concave'
controls= true
progress= true
history= true
center= true
+++

# Slide 1

___

## Slide 1.1

- Turn off alarm
- Get out of bed

___

## Slide 1.2

- Eat eggs
- Drink coffee

---

# Slide 2

___

## Slide 2.1

- Eat spaghetti
- Drink wine

___

## Slide 2.2

- Get in bed
- Count sheep